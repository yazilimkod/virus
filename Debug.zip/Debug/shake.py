import pyautogui
import pygetwindow as gw
import random
import time

print("Ekran titreme başlatıldı...")

win = gw.getActiveWindow()

while True:

    # pencere titretme
    if win is not None:
        dx = random.randint(-20, 20)
        dy = random.randint(-20, 20)
        win.moveTo(win.left + dx, win.top + dy)

    # fare titretme
    x, y = pyautogui.position()
    pyautogui.moveTo(x + random.randint(-20,20),
                     y + random.randint(-20,20),
                     duration=0)

    time.sleep(0.03)