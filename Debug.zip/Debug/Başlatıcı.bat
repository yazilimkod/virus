python shake.py
start FakeVirus.exe
